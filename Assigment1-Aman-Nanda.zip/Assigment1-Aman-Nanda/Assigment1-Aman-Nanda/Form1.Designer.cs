﻿namespace Assigment1_Aman_Nanda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.htmlbl = new System.Windows.Forms.Label();
            this.csslbl = new System.Windows.Forms.Label();
            this.phplbl = new System.Windows.Forms.Label();
            this.clbl = new System.Windows.Forms.Label();
            this.javalbl = new System.Windows.Forms.Label();
            this.rubylbl = new System.Windows.Forms.Label();
            this.htmltxt = new System.Windows.Forms.TextBox();
            this.csstxt = new System.Windows.Forms.TextBox();
            this.phptxt = new System.Windows.Forms.TextBox();
            this.ctxt = new System.Windows.Forms.TextBox();
            this.javatxt = new System.Windows.Forms.TextBox();
            this.rubytxt = new System.Windows.Forms.TextBox();
            this.avggrd = new System.Windows.Forms.Button();
            this.avggrdlbl = new System.Windows.Forms.Label();
            this.avggrdtxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.htmllbl1 = new System.Windows.Forms.Label();
            this.csslbl1 = new System.Windows.Forms.Label();
            this.phplbl1 = new System.Windows.Forms.Label();
            this.clbl1 = new System.Windows.Forms.Label();
            this.javalbl1 = new System.Windows.Forms.Label();
            this.rubylbl1 = new System.Windows.Forms.Label();
            this.avggrdlbl1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // htmlbl
            // 
            this.htmlbl.AutoSize = true;
            this.htmlbl.Location = new System.Drawing.Point(109, 48);
            this.htmlbl.Name = "htmlbl";
            this.htmlbl.Size = new System.Drawing.Size(37, 13);
            this.htmlbl.TabIndex = 0;
            this.htmlbl.Text = "HTML";
            this.htmlbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // csslbl
            // 
            this.csslbl.AutoSize = true;
            this.csslbl.Location = new System.Drawing.Point(109, 74);
            this.csslbl.Name = "csslbl";
            this.csslbl.Size = new System.Drawing.Size(28, 13);
            this.csslbl.TabIndex = 1;
            this.csslbl.Text = "CSS";
            this.csslbl.Click += new System.EventHandler(this.label2_Click);
            // 
            // phplbl
            // 
            this.phplbl.AutoSize = true;
            this.phplbl.Location = new System.Drawing.Point(109, 99);
            this.phplbl.Name = "phplbl";
            this.phplbl.Size = new System.Drawing.Size(29, 13);
            this.phplbl.TabIndex = 2;
            this.phplbl.Text = "PHP";
            // 
            // clbl
            // 
            this.clbl.AutoSize = true;
            this.clbl.Location = new System.Drawing.Point(109, 121);
            this.clbl.Name = "clbl";
            this.clbl.Size = new System.Drawing.Size(14, 13);
            this.clbl.TabIndex = 3;
            this.clbl.Text = "C";
            // 
            // javalbl
            // 
            this.javalbl.AutoSize = true;
            this.javalbl.Location = new System.Drawing.Point(109, 143);
            this.javalbl.Name = "javalbl";
            this.javalbl.Size = new System.Drawing.Size(33, 13);
            this.javalbl.TabIndex = 4;
            this.javalbl.Text = "JAVA";
            // 
            // rubylbl
            // 
            this.rubylbl.AutoSize = true;
            this.rubylbl.Location = new System.Drawing.Point(109, 172);
            this.rubylbl.Name = "rubylbl";
            this.rubylbl.Size = new System.Drawing.Size(37, 13);
            this.rubylbl.TabIndex = 5;
            this.rubylbl.Text = "RUBY";
            // 
            // htmltxt
            // 
            this.htmltxt.Location = new System.Drawing.Point(265, 40);
            this.htmltxt.Name = "htmltxt";
            this.htmltxt.Size = new System.Drawing.Size(100, 20);
            this.htmltxt.TabIndex = 6;
            // 
            // csstxt
            // 
            this.csstxt.Location = new System.Drawing.Point(265, 67);
            this.csstxt.Name = "csstxt";
            this.csstxt.Size = new System.Drawing.Size(100, 20);
            this.csstxt.TabIndex = 7;
            // 
            // phptxt
            // 
            this.phptxt.Location = new System.Drawing.Point(265, 96);
            this.phptxt.Name = "phptxt";
            this.phptxt.Size = new System.Drawing.Size(100, 20);
            this.phptxt.TabIndex = 8;
            // 
            // ctxt
            // 
            this.ctxt.Location = new System.Drawing.Point(265, 118);
            this.ctxt.Name = "ctxt";
            this.ctxt.Size = new System.Drawing.Size(100, 20);
            this.ctxt.TabIndex = 9;
            // 
            // javatxt
            // 
            this.javatxt.Location = new System.Drawing.Point(265, 140);
            this.javatxt.Name = "javatxt";
            this.javatxt.Size = new System.Drawing.Size(100, 20);
            this.javatxt.TabIndex = 10;
            // 
            // rubytxt
            // 
            this.rubytxt.Location = new System.Drawing.Point(265, 169);
            this.rubytxt.Name = "rubytxt";
            this.rubytxt.Size = new System.Drawing.Size(100, 20);
            this.rubytxt.TabIndex = 11;
            // 
            // avggrd
            // 
            this.avggrd.Location = new System.Drawing.Point(193, 209);
            this.avggrd.Name = "avggrd";
            this.avggrd.Size = new System.Drawing.Size(75, 23);
            this.avggrd.TabIndex = 12;
            this.avggrd.Text = "Calculate";
            this.avggrd.UseVisualStyleBackColor = true;
            this.avggrd.Click += new System.EventHandler(this.avggrd_Click);
            // 
            // avggrdlbl
            // 
            this.avggrdlbl.AutoSize = true;
            this.avggrdlbl.Location = new System.Drawing.Point(109, 255);
            this.avggrdlbl.Name = "avggrdlbl";
            this.avggrdlbl.Size = new System.Drawing.Size(58, 13);
            this.avggrdlbl.TabIndex = 13;
            this.avggrdlbl.Text = "Avg Grade";
            this.avggrdlbl.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // avggrdtxtbox
            // 
            this.avggrdtxtbox.Location = new System.Drawing.Point(265, 255);
            this.avggrdtxtbox.Name = "avggrdtxtbox";
            this.avggrdtxtbox.Size = new System.Drawing.Size(100, 20);
            this.avggrdtxtbox.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Average Grade Calculator";
            // 
            // htmllbl1
            // 
            this.htmllbl1.AutoSize = true;
            this.htmllbl1.Location = new System.Drawing.Point(414, 46);
            this.htmllbl1.Name = "htmllbl1";
            this.htmllbl1.Size = new System.Drawing.Size(0, 13);
            this.htmllbl1.TabIndex = 16;
            // 
            // csslbl1
            // 
            this.csslbl1.AutoSize = true;
            this.csslbl1.Location = new System.Drawing.Point(414, 74);
            this.csslbl1.Name = "csslbl1";
            this.csslbl1.Size = new System.Drawing.Size(0, 13);
            this.csslbl1.TabIndex = 17;
            // 
            // phplbl1
            // 
            this.phplbl1.AutoSize = true;
            this.phplbl1.Location = new System.Drawing.Point(414, 99);
            this.phplbl1.Name = "phplbl1";
            this.phplbl1.Size = new System.Drawing.Size(0, 13);
            this.phplbl1.TabIndex = 18;
            // 
            // clbl1
            // 
            this.clbl1.AutoSize = true;
            this.clbl1.Location = new System.Drawing.Point(405, 121);
            this.clbl1.Name = "clbl1";
            this.clbl1.Size = new System.Drawing.Size(0, 13);
            this.clbl1.TabIndex = 19;
            // 
            // javalbl1
            // 
            this.javalbl1.AutoSize = true;
            this.javalbl1.Location = new System.Drawing.Point(405, 143);
            this.javalbl1.Name = "javalbl1";
            this.javalbl1.Size = new System.Drawing.Size(0, 13);
            this.javalbl1.TabIndex = 20;
            // 
            // rubylbl1
            // 
            this.rubylbl1.AutoSize = true;
            this.rubylbl1.Location = new System.Drawing.Point(405, 172);
            this.rubylbl1.Name = "rubylbl1";
            this.rubylbl1.Size = new System.Drawing.Size(0, 13);
            this.rubylbl1.TabIndex = 21;
            // 
            // avggrdlbl1
            // 
            this.avggrdlbl1.AutoSize = true;
            this.avggrdlbl1.Location = new System.Drawing.Point(414, 258);
            this.avggrdlbl1.Name = "avggrdlbl1";
            this.avggrdlbl1.Size = new System.Drawing.Size(0, 13);
            this.avggrdlbl1.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.avggrdlbl1);
            this.Controls.Add(this.rubylbl1);
            this.Controls.Add(this.javalbl1);
            this.Controls.Add(this.clbl1);
            this.Controls.Add(this.phplbl1);
            this.Controls.Add(this.csslbl1);
            this.Controls.Add(this.htmllbl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.avggrdtxtbox);
            this.Controls.Add(this.avggrdlbl);
            this.Controls.Add(this.avggrd);
            this.Controls.Add(this.rubytxt);
            this.Controls.Add(this.javatxt);
            this.Controls.Add(this.ctxt);
            this.Controls.Add(this.phptxt);
            this.Controls.Add(this.csstxt);
            this.Controls.Add(this.htmltxt);
            this.Controls.Add(this.rubylbl);
            this.Controls.Add(this.javalbl);
            this.Controls.Add(this.clbl);
            this.Controls.Add(this.phplbl);
            this.Controls.Add(this.csslbl);
            this.Controls.Add(this.htmlbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label htmlbl;
        private System.Windows.Forms.Label csslbl;
        private System.Windows.Forms.Label phplbl;
        private System.Windows.Forms.Label clbl;
        private System.Windows.Forms.Label javalbl;
        private System.Windows.Forms.Label rubylbl;
        private System.Windows.Forms.TextBox htmltxt;
        private System.Windows.Forms.TextBox csstxt;
        private System.Windows.Forms.TextBox phptxt;
        private System.Windows.Forms.TextBox ctxt;
        private System.Windows.Forms.TextBox javatxt;
        private System.Windows.Forms.TextBox rubytxt;
        private System.Windows.Forms.Button avggrd;
        private System.Windows.Forms.Label avggrdlbl;
        private System.Windows.Forms.TextBox avggrdtxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label htmllbl1;
        private System.Windows.Forms.Label csslbl1;
        private System.Windows.Forms.Label phplbl1;
        private System.Windows.Forms.Label clbl1;
        private System.Windows.Forms.Label javalbl1;
        private System.Windows.Forms.Label rubylbl1;
        private System.Windows.Forms.Label avggrdlbl1;
    }
}

